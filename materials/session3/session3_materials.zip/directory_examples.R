### In this script, you will use R functions to explore the files in your project folder

# Run the following code to see if your directory structure is correct.
if(file.exists('session1/session1_data/example_outpatient.csv') & file.exists('project/EPI Data.xls')){
  print('your directory looks good!')
}else{
  print('Uh-oh! Something isnt right in your directory.')
}

# Get the current directory.

# Display the contents of this directory.

# Pull in the session 1 outpatient data using a relative path.

# Pull in the session 1 outpatient data using an absolute path.

# Set the working directory to session 2.

# Pull in the session 2 data using a relative path.

# Set the directory back to the project space using a relative path.

# Get the current directory.

